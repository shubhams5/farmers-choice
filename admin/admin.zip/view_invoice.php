<?php
   include('include/connection.php');
   session_start();
   
   $user_check = $_SESSION['login_user'];
   
   $ses_sql = mysqli_query($connect,"select username from admin where username = '$user_check' ");
   
   $row = mysqli_fetch_array($ses_sql,MYSQLI_ASSOC);
   
   $login_session = $row['username'];
   
   if(!isset($_SESSION['login_user'])){
      header("location:index.php");
      die();
   }
?>



<!DOCTYPE html>
<html>

<head>
    <?php include "include/linker.php";?>
    <style>
    
    .invoice-title h2, .invoice-title h3 {
    display: inline-block;
}

.table > tbody > tr > .no-line {
    border-top: none;
}

.table > thead > tr > .no-line {
    border-bottom: none;
}

.table > tbody > tr > .thick-line {
    border-top: 2px solid;
}

    </style>
</head>

<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Please wait...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <!-- Top Bar -->
    <?php include "include/header.php"; ?>
    <!-- #Top Bar -->
    <section>
        
        <?php include "include/sidebar.php"; ?>
        <!-- #END# Left Sidebar -->
        <!-- Right Sidebar -->
    </section>

    <section class="content">
        
        <div class="container-fluid">
            <div class="block-header">
                <h2>Invoice</h2>
            </div>
            <?php
                
                $id = $_GET['id'];
                $sql_invoice = "SELECT * FROM oders WHERE id = '$id'";
                $sql_invoice_query = mysqli_query($connect, $sql_invoice);
                $order_row = mysqli_fetch_assoc($sql_invoice_query);
                
                
                $address_id = $order_row['address_id'];
                $sql_address = "SELECT * FROM address WHERE id = '$address_id'";
                $sql_address_query = mysqli_query($connect, $sql_address);
                $sql_address_row = mysqli_fetch_assoc($sql_address_query);
                
                
                $sql_order = $order_row['orderid'];
                $sql_userid = $order_row['userid'];
                $sql_cart = "SELECT * FROM cart WHERE orderid = '$sql_order' AND userid = '$sql_userid'";
                $sql_cart_query = mysqli_query($connect, $sql_cart);
                
                
            
            
            ?>
<div class="card container">
    <div class="row">
        <div class="col-xs-12">
    		<div class="invoice-title">
    			<h2>Invoice</h2><h3 class="pull-right"><?php echo $order_row['orderid'];?></h3>
    		</div>
    		<hr>
    		<div class="row">
    			<div class="col-xs-6">
    				<address>
    				<strong>Billed To:</strong><br>
    					<?php echo $sql_address_row['fname']." ".$sql_address_row['lname']; ?><br>
    					<?php echo $sql_address_row['address']; ?><br>
    					<?php echo $sql_address_row['city']; ?><br>
    					<?php echo $sql_address_row['state']; ?>, <?php echo $sql_address_row['pincode']; ?><br>
    					<b><?php echo $sql_address_row['mobile']; ?></b>
    				</address>
    			</div>
    			<div class="col-xs-6 text-right">
    				<address>
        			<strong>Shipped To:</strong><br>
    					<?php echo $sql_address_row['fname']." ".$sql_address_row['lname']; ?><br>
    					<?php echo $sql_address_row['address']; ?><br>
    					<?php echo $sql_address_row['city']; ?><br>
    					<?php echo $sql_address_row['state']; ?>, <?php echo $sql_address_row['pincode']; ?><br>
    					<b><?php echo $sql_address_row['mobile']; ?></b>
    				</address>
    			</div>
    		</div>
    		<div class="row">
    			<div class="col-xs-6">
    				<address>
    					<strong>Payment Method:</strong><br>
    					<?php echo $order_row['PG_TYPE'];?><br>
    		
    				</address>
    			</div>
    			<div class="col-xs-6 text-right">
    				<address>
    					<strong>Order Date:</strong><br>
    					<?php echo date('F j, Y',strtotime($order_row['created_at'])); ?><br><br>
    				</address>
    			</div>
    		</div>
    	</div>
    </div>
    
    <div class="row">
    	<div class="col-md-12">
    		<div class="panel panel-default">
    			<div class="panel-heading">
    				<h3 class="panel-title"><strong>Order summary</strong></h3>
    			</div>
    			<div class="panel-body">
    				<div class="table-responsive">
    					<table class="table table-condensed">
    						<thead>
                                <tr>
        							<td><strong>Item Name</strong></td>
        							<td class="text-center"><strong>Price</strong></td>
        							<td class="text-center"><strong>Quantity</strong></td>
        							<td class="text-right"><strong>Totals</strong></td>
                                </tr>
    						</thead>
    						<tbody>
    							<!-- foreach ($order->lineItems as $line) or some such thing here -->
    							<?php
    							
    							while($sql_cart_row = mysqli_fetch_assoc($sql_cart_query))
                                {
    							
    							?>
    							<tr>
    								<td><?php echo $sql_cart_row['product_name']; ?></td>
    								<td class="text-center"><?php echo $sql_cart_row['product_price']; ?></td>
    								<td class="text-center"><?php echo $sql_cart_row['qty']; ?></td>
    								<td class="text-right">
    								<?php 
    								    
    								    $pcart = $sql_cart_row['product_price'];
    								    $qcart = $sql_cart_row['qty'];
    								    $price_cart = $pcart * $qcart;
    								    
    								    echo $price_cart;
    								    
    							    
    							    ?>
    							    </td>
    							</tr>
    							<?php } ?>
                                
    							<tr>
    								<td class="thick-line"></td>
    								<td class="thick-line"></td>
    								<td class="thick-line text-center"><strong>Subtotal</strong></td>
    								<td class="thick-line text-right"><?php echo "Rs. ".$order_row['total_invoice'];?></td>
    							</tr>
    							<tr>
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-center"><strong>Shipping</strong></td>
    								<td class="no-line text-right">Rs 40</td>
    							</tr>
    							<tr>
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-center"><strong>Total</strong></td>
    								<td class="no-line text-right"><?php $final_invoice = $order_row['total_invoice'] + 40; echo "Rs. ".$final_invoice; ?></td>
    							</tr>
    						</tbody>
    					</table>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
</div>


        
    </div>
    </section>

    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="plugins/jquery-countto/jquery.countTo.js"></script>

    <!-- Morris Plugin Js -->
    <script src="plugins/raphael/raphael.min.js"></script>
    <script src="plugins/morrisjs/morris.js"></script>

    <!-- ChartJs -->
    <script src="plugins/chartjs/Chart.bundle.js"></script>

    <!-- Flot Charts Plugin Js -->
    <script src="plugins/flot-charts/jquery.flot.js"></script>
    <script src="plugins/flot-charts/jquery.flot.resize.js"></script>
    <script src="plugins/flot-charts/jquery.flot.pie.js"></script>
    <script src="plugins/flot-charts/jquery.flot.categories.js"></script>
    <script src="plugins/flot-charts/jquery.flot.time.js"></script>

    <!-- Sparkline Chart Plugin Js -->
    <script src="plugins/jquery-sparkline/jquery.sparkline.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/index.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
</body>

</html>
